import{ Component} from '@angular/core';

@Component ({
    selector: 'features',
    templateUrl : './features.component.html',
    //styleUrls :['./Travel.component.css']

})

export class FeaturesComponent{
}