import{ Component} from '@angular/core';

@Component ({
    selector: 'home',
    templateUrl : './Home.component.html',
    //styleUrls :['./Travel.component.css']

})

export class HomeComponent{
   
}