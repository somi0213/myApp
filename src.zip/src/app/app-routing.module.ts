import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from './../Home/Home.component';
import {TravelComponent} from './../Travel/Travel.component';
import {TravelLoginComponent} from './../Travel_login/Travel_login.component';
import {FeaturesComponent} from './../Features/features.component';

const routes: Routes = [

  { path:'home', component:TravelComponent},
 { path:'features', component:FeaturesComponent},
 { path:'Travel_login', component:TravelLoginComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

