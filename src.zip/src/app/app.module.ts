import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TravelComponent } from './../Travel/Travel.component';
import { TravelLoginComponent } from './../Travel_login/Travel_login.component';
import { HomeComponent } from './../Home/Home.component';
import { FeaturesComponent } from './../Features/features.component';
@NgModule({
  declarations: [
    AppComponent, TravelComponent, TravelLoginComponent,HomeComponent,FeaturesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
