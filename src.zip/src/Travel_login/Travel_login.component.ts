import{Component} from '@angular/core';

@Component ({
    selector : 'Travel_login',
    templateUrl : './Travel_login.component.html',
    styleUrls : ['./Travel_login.component.css'] 
})

export class TravelLoginComponent
{
    title :string = "Make Journey Beautiful"
}